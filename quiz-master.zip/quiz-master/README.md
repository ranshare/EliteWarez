## Synopsis

It lets you create multiple questionnaires containing questions of type essay, objective with unique response and objective with multiple choice.


## Motivation

I created this system in one night only to assess students in a course. Now I am leaving public to help in a collaboration in a private forum.

## Installation

Create a vhost on Apache to facilitate and run the project without changing anything.

## Tests

http://quiz.local-ebosco.com/quiz/questionario/index.php?acao=questionario&chave=[key]

http://quiz.local-ebosco.com/quiz/admin/index.php?acao=listarAlunos

http://quiz.local-ebosco.com/ is a vhost

## Contributors

For now just me. Feel free to contribute.

## License

none
