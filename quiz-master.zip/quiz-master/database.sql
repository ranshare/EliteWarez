-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.6.17 - MySQL Community Server (GPL)
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para sis_questionario
CREATE DATABASE IF NOT EXISTS `sis_questionario` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `sis_questionario`;


-- Copiando estrutura para tabela sis_questionario.aluno
CREATE TABLE IF NOT EXISTS `aluno` (
  `idaluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cadastro` datetime NOT NULL,
  PRIMARY KEY (`idaluno`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.aluno: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `aluno` DISABLE KEYS */;
INSERT INTO `aluno` (`idaluno`, `nome`, `email`, `cadastro`) VALUES
	(1, 'Erick Bosco', 'erickbosco@hotmail.com', '2015-03-25 14:02:22');
/*!40000 ALTER TABLE `aluno` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.pergunta
CREATE TABLE IF NOT EXISTS `pergunta` (
  `idpergunta` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` text NOT NULL,
  `idpergunta_tipo` int(11) NOT NULL,
  `cadastro` datetime NOT NULL,
  PRIMARY KEY (`idpergunta`),
  KEY `fk_pergunta_idpergunta_tipo` (`idpergunta_tipo`),
  CONSTRAINT `fk_pergunta_idpergunta_tipo` FOREIGN KEY (`idpergunta_tipo`) REFERENCES `pergunta_tipo` (`idpergunta_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.pergunta: ~21 rows (aproximadamente)
/*!40000 ALTER TABLE `pergunta` DISABLE KEYS */;
INSERT INTO `pergunta` (`idpergunta`, `descricao`, `idpergunta_tipo`, `cadastro`) VALUES
	(1, 'De acordo com o que você entendeu nas aulas, o que é PHP e para que serve', 1, '2015-03-25 14:03:44'),
	(2, 'Podemos dizer que recursividade é ...', 2, '2015-03-25 23:53:11'),
	(3, 'É correto afirmar que PHP é', 3, '2015-03-26 01:42:56'),
	(4, 'PHP é', 2, '2015-03-27 00:22:11'),
	(5, 'Cite pelo menos 2 grandes empresas e/ou produtos que usam PHP como linguagem principal', 1, '2015-03-27 00:25:47'),
	(6, 'PHP é multiplataforma. O que isso significa?', 1, '2015-03-27 00:28:35'),
	(7, 'Apache, IIS e PWS. O que são essas coisas?', 2, '2015-03-27 00:29:38'),
	(8, 'Fale sobre a tipagem dinâmica do PHP', 1, '2015-03-27 00:33:11'),
	(9, 'O arquivo de configurações do PHP, onde podemos habilitar e desabilitar recursos e funcionalidades, chame-se', 2, '2015-03-27 00:34:47'),
	(10, 'Podemos utilizar as tags de abertura e fechamento do PHP de quatro formas, porém somente uma é mais legível e também garantida que irá funcionar em qualquer servidor. Assinale ela abaixo', 2, '2015-03-27 00:38:56'),
	(11, 'Qual das opções abaixo <strong>não</strong> é um comentário válido em PHP', 2, '2015-03-27 00:48:34'),
	(12, 'Escreva com suas palavras o que é uma variável e o que é uma constante em PHP (assim como em Java, C, Python, ...)', 1, '2015-03-27 00:53:07'),
	(13, 'O que é HTTP?', 1, '2015-03-27 00:57:46'),
	(14, 'Existem 8 métodos HTTP, mas apenas 5 são mais utilizados e usamos no curso apenas 2. Quais são eles?', 1, '2015-03-27 00:59:46'),
	(15, 'Arrays superglobais do PHP são', 2, '2015-03-27 01:00:33'),
	(16, 'Precisamos muitas vezes executar o mesmo trecho de código em vários lugares diferentes do script. Ao invés de repetir esses códigos, podemos resolver esse problema com', 2, '2015-03-27 01:04:26'),
	(17, 'O que é e/ou pra que serve a linguagem SQL', 1, '2015-03-27 01:08:34'),
	(18, 'Na empresa XJ-ENTERPRISE existe um servidor de banco de dados MySQL cujo endereço IP é <strong>173.194.118.239</strong>. Os dados de autenticação fornecidos são usuário <strong>dev</strong> e a senha é <strong>123</strong>. Como já havia uma instância MySQL nesse servidor, a empresa instalou o novo SGBD escutando na porta <strong>3308</strong>. O nome do banco de dados ou schema é <strong>developer</strong>. Escreva em no máximo 3 linhas o script PHP para conectar nesse servidor e selecionar a base de dados informada.', 1, '2015-03-27 01:08:34'),
	(19, 'Qual a diferença entre mysql_connect e mysql_pconnect?', 1, '2015-03-27 01:17:20'),
	(20, 'Escreva um script PHP que guarde/armazene (por atribuição) dois números em duas variáveis distintas e mostre a soma das duas', 1, '2015-03-27 01:19:06'),
	(22, '<strong>[RESPOSTA PESSOAL]</strong> Entre 1 e 10, qual nota você daria para o curso e para o professor, individualmente? Ex.: Curso nota <i>M</i> e professor nota <i>N</i>.<br>\r\nAlém disso, escreva livremente sobre os pontos negativos do curso que poderiam ser melhorados e quais cursos relacionados ao desenvolvimento de software você gostaria de fazer...', 1, '2015-03-27 01:33:19');
/*!40000 ALTER TABLE `pergunta` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.pergunta_alternativa
CREATE TABLE IF NOT EXISTS `pergunta_alternativa` (
  `idpergunta_alternativa` int(11) NOT NULL AUTO_INCREMENT,
  `idpergunta` int(11) NOT NULL,
  `descricao` text NOT NULL,
  `cadastro` datetime NOT NULL,
  PRIMARY KEY (`idpergunta_alternativa`),
  KEY `fk_pergunta_idpergunta_tipo` (`idpergunta`),
  CONSTRAINT `fk_pergunta_alternativa_idpergunta` FOREIGN KEY (`idpergunta`) REFERENCES `pergunta` (`idpergunta`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.pergunta_alternativa: ~33 rows (aproximadamente)
/*!40000 ALTER TABLE `pergunta_alternativa` DISABLE KEYS */;
INSERT INTO `pergunta_alternativa` (`idpergunta_alternativa`, `idpergunta`, `descricao`, `cadastro`) VALUES
	(1, 2, 'uma subrotina pode invocar a si mesma.', '2015-03-25 23:54:02'),
	(2, 2, 'uma função void, ou seja, não retornará nada.', '2015-03-25 23:54:02'),
	(3, 2, 'uma função nativa do PHP', '2015-03-25 23:54:02'),
	(4, 3, 'server-side', '2015-03-26 01:43:16'),
	(5, 3, 'multiplataforma', '2015-03-26 01:43:16'),
	(6, 3, 'tipagem dinâmica', '2015-03-26 01:43:16'),
	(7, 3, 'case insensitive', '2015-03-26 01:43:16'),
	(8, 4, 'compilada', '2015-03-27 00:24:01'),
	(9, 4, 'interpretada', '2015-03-27 00:24:01'),
	(10, 7, 'servidores web', '2015-03-27 00:30:32'),
	(11, 7, 'sistemas operacionais', '2015-03-27 00:30:32'),
	(12, 7, 'linguagens de programação', '2015-03-27 00:30:32'),
	(13, 7, 'bancos de dados', '2015-03-27 00:30:32'),
	(14, 9, 'php.ini', '2015-03-27 00:34:58'),
	(15, 9, 'httpd.conf', '2015-03-27 00:34:58'),
	(16, 9, 'vhost.conf', '2015-03-27 00:34:58'),
	(17, 9, 'pg_hba.conf', '2015-03-27 00:34:58'),
	(18, 10, '&lt;?php ?&gt;', '2015-03-27 00:39:35'),
	(19, 10, '&lt;script language=&quot;php&quot;&gt;  &lt;/script&gt;', '2015-03-27 00:39:35'),
	(20, 10, '&lt;?  ?&gt;', '2015-03-27 00:39:35'),
	(21, 10, '&lt;% %&gt;', '2015-03-27 00:39:35'),
	(22, 11, '// comentário de uma linha', '2015-03-27 00:48:55'),
	(23, 11, '# comentário de uma linha', '2015-03-27 00:48:55'),
	(24, 11, '/* comentário de múltiplas linhas */', '2015-03-27 00:48:55'),
	(25, 11, '{ comentário de uma linha }', '2015-03-27 00:48:55'),
	(26, 15, 'variáveis nativas que estão sempre disponíveis em todos escopos.\r', '2015-03-27 01:01:02'),
	(27, 15, 'vetores associativos', '2015-03-27 01:01:02'),
	(28, 15, 'vetores não associativos', '2015-03-27 01:01:02'),
	(29, 15, 'variáveis criadas pelo programador para serem passadas por parâmetro de funções', '2015-03-27 01:01:02'),
	(30, 16, 'funções', '2015-03-27 01:04:46'),
	(31, 16, 'arrays', '2015-03-27 01:04:46'),
	(32, 16, 'arquivos xml', '2015-03-27 01:04:46'),
	(33, 16, 'formulários HTML', '2015-03-27 01:04:46');
/*!40000 ALTER TABLE `pergunta_alternativa` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.pergunta_tipo
CREATE TABLE IF NOT EXISTS `pergunta_tipo` (
  `idpergunta_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) NOT NULL,
  PRIMARY KEY (`idpergunta_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.pergunta_tipo: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `pergunta_tipo` DISABLE KEYS */;
INSERT INTO `pergunta_tipo` (`idpergunta_tipo`, `descricao`) VALUES
	(1, 'Dissertativas'),
	(2, 'Objetivas - Resposta Única'),
	(3, 'Objetivas - Múltiplas Respostas');
/*!40000 ALTER TABLE `pergunta_tipo` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.questionario
CREATE TABLE IF NOT EXISTS `questionario` (
  `idquestionario` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `subtitulo` varchar(255) NOT NULL,
  `cadastro` datetime NOT NULL,
  `avisos` text,
  PRIMARY KEY (`idquestionario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.questionario: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `questionario` DISABLE KEYS */;
INSERT INTO `questionario` (`idquestionario`, `titulo`, `subtitulo`, `cadastro`, `avisos`) VALUES
	(1, 'Curso de PHP', 'Questionário sobre assuntos abordados no curso', '2015-03-25 13:58:32', '<strong>Anteção!</strong> O questionário abaixo tem dois objetivos: (1) servir como auto-avaliação para o instrutor, mostrando o quanto a turma, como um todo, absorveu as informações; (2) mostrar em quais assuntos o ensino/aprendizado foi mais eficiente.\r\n<br>\r\nPara responder as questões, você pode, se assim o desejar, consultar <strong>apenas os códigos-fontes</strong> desenvolvidos nas aulas.\r\n<br>\r\n<strong>Não consulte os slides</strong> pois assim o questionário não cumprirá seus objetivos.<br>\r\nA resposta da PERGUNTA PESSOAL será armazenada separadamente das outras respostas, de modo que não será possível identificar o aluno que respondeu, visando deixar a resposta o mais espontânea/sincera possível.');
/*!40000 ALTER TABLE `questionario` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.questionario_x_aluno
CREATE TABLE IF NOT EXISTS `questionario_x_aluno` (
  `idquestionario_x_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `idquestionario` int(11) NOT NULL,
  `idaluno` int(11) NOT NULL,
  `cadastro` datetime NOT NULL,
  `respondido` datetime DEFAULT NULL,
  `nota` tinyint(4) DEFAULT NULL,
  `hash` char(32) NOT NULL,
  PRIMARY KEY (`idquestionario_x_aluno`),
  KEY `fk_idquestionario` (`idquestionario`),
  KEY `fk_idaluno` (`idaluno`),
  CONSTRAINT `fk_idaluno` FOREIGN KEY (`idaluno`) REFERENCES `aluno` (`idaluno`),
  CONSTRAINT `fk_idquestionario` FOREIGN KEY (`idquestionario`) REFERENCES `questionario` (`idquestionario`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.questionario_x_aluno: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `questionario_x_aluno` DISABLE KEYS */;
INSERT INTO `questionario_x_aluno` (`idquestionario_x_aluno`, `idquestionario`, `idaluno`, `cadastro`, `respondido`, `nota`, `hash`) VALUES
	(1, 1, 1, '2015-03-25 14:04:58', NULL, NULL, 'DEE94F67E4662FB20D76D1D86F9DD4B2');
/*!40000 ALTER TABLE `questionario_x_aluno` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.questionario_x_pergunta
CREATE TABLE IF NOT EXISTS `questionario_x_pergunta` (
  `idquestionario` int(11) NOT NULL,
  `idpergunta` int(11) NOT NULL,
  `ordenacao` int(11) NOT NULL,
  PRIMARY KEY (`idquestionario`,`idpergunta`),
  KEY `fk_idpergunta` (`idpergunta`),
  CONSTRAINT `fk_idpergunta` FOREIGN KEY (`idpergunta`) REFERENCES `pergunta` (`idpergunta`),
  CONSTRAINT `fk_questionario` FOREIGN KEY (`idquestionario`) REFERENCES `questionario` (`idquestionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.questionario_x_pergunta: ~21 rows (aproximadamente)
/*!40000 ALTER TABLE `questionario_x_pergunta` DISABLE KEYS */;
INSERT INTO `questionario_x_pergunta` (`idquestionario`, `idpergunta`, `ordenacao`) VALUES
	(1, 1, 1),
	(1, 2, 2),
	(1, 3, 3),
	(1, 4, 4),
	(1, 5, 5),
	(1, 6, 6),
	(1, 7, 7),
	(1, 8, 8),
	(1, 9, 9),
	(1, 10, 10),
	(1, 11, 11),
	(1, 12, 12),
	(1, 13, 13),
	(1, 14, 14),
	(1, 15, 15),
	(1, 16, 16),
	(1, 17, 17),
	(1, 18, 18),
	(1, 19, 19),
	(1, 20, 20),
	(1, 22, 22);
/*!40000 ALTER TABLE `questionario_x_pergunta` ENABLE KEYS */;


-- Copiando estrutura para tabela sis_questionario.resposta
CREATE TABLE IF NOT EXISTS `resposta` (
  `idresposta` int(11) NOT NULL AUTO_INCREMENT,
  `idpergunta` int(11) NOT NULL,
  `idaluno` int(11) NOT NULL,
  `resposta` text NOT NULL,
  PRIMARY KEY (`idresposta`),
  KEY `fk_resposta_idpergunta` (`idpergunta`),
  KEY `fk_resposta_idaluno` (`idaluno`),
  CONSTRAINT `fk_resposta_idaluno` FOREIGN KEY (`idaluno`) REFERENCES `aluno` (`idaluno`),
  CONSTRAINT `fk_resposta_idpergunta` FOREIGN KEY (`idpergunta`) REFERENCES `pergunta` (`idpergunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela sis_questionario.resposta: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `resposta` DISABLE KEYS */;
/*!40000 ALTER TABLE `resposta` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
