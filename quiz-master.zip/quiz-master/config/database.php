<?php

return array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'sis_questionario',
    'char_set' => 'utf8'
);
