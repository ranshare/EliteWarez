<?php

return array(
    'compress_js' => false,
    'compress_css' => false,
    'friendly_url' => false,
    'dir_project' => 'quiz/',
    'page_404' => '404.php',
    'base_url' => "http://{$_SERVER["HTTP_HOST"]}/",
    'base_dir' => "{$_SERVER["DOCUMENT_ROOT"]}/",
);
