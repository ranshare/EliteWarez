<?php

return array(
    'allowed_files' => 'pdf|doc|docx|xls|xlsx|txt|ppt|pptx|zip',
    'allowed_images' => 'jpg|jpeg|png|gif|bmp'
);
