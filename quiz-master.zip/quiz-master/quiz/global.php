<?php

header('Content-Type: text/html; charset=utf-8');

header("Pragma: no-cache");
header("Expires: -1");
header("Cache-Control: no-cache, must-revalidate");
date_default_timezone_set("America/Sao_Paulo");
setlocale(LC_ALL, 'pt_BR');

session_start();

define('DIR_PROJECT', $_SERVER["DOCUMENT_ROOT"]);

/* load configuration files */
$config   = require DIR_PROJECT . '/config/config.php';
$database = require DIR_PROJECT . '/config/database.php';
$upload   = require DIR_PROJECT . '/config/upload.php';

define('HOST_DB', $database['host']);
define('DBNAME_DB', $database['database']);
define('USER_DB', $database['username']);
define('PASS_DB', $database['password']);
define('CHARSET_DB', $database['char_set']);

define("DIR_PROJETO", $config['dir_project']);
define("PAGINA_NAO_ENCONTRADA", $config['page_404']);
define("URL_RAIZ", $config['base_url']);
define("URL_SITE", $config['base_url'] . $config['dir_project']);
define("DIR_SITE", $config['base_dir'] . $config['dir_project']);
define("DIR_BASE", $config['base_dir']);
define("CMP_ARQ", $upload['allowed_files']);
define("CMP_IMG", $upload['allowed_images']);

define("URL_AMIGAVEL", $config['friendly_url']);
define("COMPRIMIR_CSS", $config['compress_css']);
define("COMPRIMIR_JS", $config['compress_js']);

/* active/inactive modules          directory module */
define("MOD_ADMIN", true);          $MOD_SITE[] = "admin";
define("MOD_QUESTIONARIO", true);   $MOD_SITE[] = "questionario";

function autoload($class) {
    $dir = strtolower(substr($class, (strlen($class) - 3), strlen($class)));
    if ($dir == "mod") {
        $dir = "model";
    } else {
        $dir = "controller";
    }
   
    if (file_exists(DIR_SITE . $dir . "/" . $class . ".class.php")) {
        require_once DIR_SITE . $dir . "/" . $class . ".class.php";
    } elseif (file_exists(DIR_SITE . $dir . "/" . $class . ".class.php")) {
        require_once DIR_SITE . $dir . "/" . $class . ".class.php";
    } else {
        $require_class = Functions::getArquivoModulo($class . ".class.php", $dir);
        if (file_exists($require_class)) {
            require_once $require_class;
        } else {
            throw new Exception('Class "' . $class . '" not found!');
        }
    }
}

spl_autoload_register("autoload");

$Functions = new Functions();