<?php

include_once "../global.php";

header("Content-type: text/css");

if (COMPRIMIR_CSS)
    ob_start(array($Functions, 'compress'));
else
    ob_start ();

/* ARQUIVOS CSS PADRAO */
include_once "global.css";
include_once "bootstrap.min.css";

/* FAZ A INCLUSAO ARQUIVOS DE CSS ESPECIFICADOS */
if (isset($_GET["files"]) && !empty($_GET["files"])) {
    $array_css = explode(",", $_GET["files"]);
    
    if (is_array($array_css)) {
        foreach ($array_css as $css) {
            if (file_exists($css)) {
                include_once $css;
            } else {
                $css_mod = $Functions->getArquivoModulo($css, "css");
                if (file_exists($css_mod)) {
                    include_once $css_mod;
                }
            }
        }
    }
}

ob_end_flush();