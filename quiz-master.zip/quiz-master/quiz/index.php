<?php
require './global.php';

header("Location: " . $Functions->gerarLink("questionario/index.php?acao=questionario"));
exit;