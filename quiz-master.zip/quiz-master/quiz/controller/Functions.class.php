<?php

class Functions {
    
    private static $instance = null;
    
    /**
     * static function to get the Functions object
     * @return Functions - return object (instance) Functions
     */
    public static function getInstance(){
        if (self::$instance == null)
            self::$instance = new Functions();
        return self::$instance;
    }

    /**
     * Funcao para gerar o link amigavel
     * @param String $input - Url que sera convertida
     * @param String $texto - Texto que fica na frente da URL
     * @param String $replace - tipo de espaco
     * @param Boolean $remove_words - se true, remove as palavras do proximo parametro
     * @param Array $words_array - array com as palavras que serao removidas
     * @return String - retorna o link amigavel
     */
    public function gerarLink($input, $texto = '', $replace = '+', $remove_words = true, $words_array = array()) {

        if (URL_AMIGAVEL) {

            $parametros = array();

            //trata link
            $texto = html_entity_decode($texto);
            //troca palavras acentuadas pela mesma palavra sem acento

            $texto = str_replace(" ", $replace, $texto);

            $texto = $this->nomeArquivo($texto);

            //tira maiuscula, remove os pontos / espaços
            //$texto = trim(ereg_replace(' +', ' ', preg_replace('/[^a-zA-Z0-9\s]/', '', $texto)));
            if ($remove_words) {
                $texto = $this->remove_words($texto, $replace, $words_array);
            }

            if (strpos($input, "?") !== false) {
                $infoUrl = explode("?", $input);
                $url = $infoUrl[0];
                //trata o texto que irá entrar no parametro
                $ParametrosUrl = $infoUrl[1];
            } else {
                $url = $input;
                //trata o texto que irá entrar no parametro
                $ParametrosUrl = "";
            }

            if ($ParametrosUrl) {

                $ParametrosUrl = html_entity_decode($ParametrosUrl);
                $ParametrosUrl = $this->nomeArquivo($ParametrosUrl);

                $ParametrosUrl = explode("&", $ParametrosUrl);

                //separa os parametros
                foreach ($ParametrosUrl as $parametrosUrl) {
                    $parametrosFinaisUrl[] = explode("=", $parametrosUrl);
                }

                //cria um array com todos os parametros, só com os valores, na ordem que foi enviada
                for ($jurl = 0; $jurl < count($parametrosFinaisUrl); $jurl++) {
                    for ($lurl = 0; $lurl < count($parametrosFinaisUrl[$jurl]); $lurl++) {
                        if ($lurl % 2 == 0) {
                            $parametros[] = urldecode($parametrosFinaisUrl[$jurl][$lurl]);
                        }
                    }
                }
            }

            //monta a url
            $paramUrlAmigavel = "";
            foreach ($parametros as $parametro) {
                $paramUrlAmigavel .= $parametro . "/";
            }

            if ($paramUrlAmigavel == "//" || $paramUrlAmigavel == "/") {
                $paramUrlAmigavel = "";
            }

            if ($url) {
                if (strpos("/", $url) === false) {
                    $url = current(explode("/", $url)) . "/";
                    $url = strpos($url, ".php") ? "" : $url;
                }
            }
            
            $urlCompleta = URL_RAIZ . $url /*. $paramUrlAmigavel*/ . $texto;
        } else {
            $urlCompleta = URL_SITE . $input;
        }

        return $urlCompleta;
    }

    public function remove_words($input, $replace, $words_array = array(), $unique_words = true) {

        $input_array = explode(' ', $input);

        $return = array();

        foreach ($input_array as $word) {
            if (!in_array($word, $words_array) && ($unique_words ? !in_array($word, $return) : true)) {
                $return[] = $word;
            }
        }

        return implode($replace, $return);
    }

    public function getDirName() {
        $dirname = "";
        $url = "http://{$_SERVER["HTTP_HOST"]}{$_SERVER["REQUEST_URI"]}";
        if (strpos($url, URL_SITE) !== false) {
            $dirname = str_replace(URL_SITE, "", $url);
            if (strpos($dirname, ".php") !== false) {
                $dirname = explode("/", $dirname);
                unset($dirname[count($dirname) - 1]);
                $dirname = implode("/", $dirname) . "/";
            }
        } else {
            $dirname = str_replace(URL_RAIZ, "", $url);
            if (strpos($dirname, ".php") !== false) {
                $dirname = explode("/", $dirname);
                unset($dirname[count($dirname) - 1]);
                $dirname = implode("/", $dirname) . "/";
            }
        }
        return $dirname;
    }

    public function getModulo() {
        $dir = self::getDirName();
        $arr = explode("/", $dir);

        return $arr[0];
    }

    public static function getArquivoModulo($arquivo, $pasta) {
        global $MOD_SITE;
        if (is_array($MOD_SITE)) {
            foreach ($MOD_SITE as $mod) {
                if (constant("MOD_" . strtoupper($mod)) === true) {
                    if (file_exists(DIR_SITE . "{$mod}/{$pasta}/{$arquivo}")) {
                        return DIR_SITE . "{$mod}/{$pasta}/{$arquivo}";
                    }
                }
            }
        }
    }

    public static function getIn($array) {
        $retorno = "";
        if (is_array($array)) {
            foreach ($array as $value) {
                $retorno .= ($retorno == "") ? $value : ",{$value}";
            }
        }
        return $retorno;
    }

    public function compress($buffer) {
        /* remove os comentarios */
        $buffer = preg_replace("!/\*[^*]*\*+([^/][^*]*\*+)*/!", "", $buffer);
        /* remove tabs, espacos, newlines, etc. */
        $buffer = str_replace(array("\r\n", "\r", "\n", "\t", "  ", "    ", "    "), "", $buffer);
        return $buffer;
    }

    public function encodeHex($value) {
        // obtem 2 hexadecimal caracteres que representam 1 caracter ASCII
        $encrypt = "";
        $value = (string) $value;
        for ($i = 0; $i < strlen($value); $i++)
            $encrypt .= dechex(ord($value[$i]));
        return $encrypt;
    }

    public function decodeHex($value) {
        // obtem 2 hexadecimal caracteres que representam 1 caracter ASCII
        $decrypt = "";
        $value = (string) $value;
        for ($i = 0; $i < strlen($value); $i+=2)
            $decrypt .= chr(hexdec(substr($value, $i, 2)));
        return $decrypt;
    }

    public function uploadArquivo($file, $tabela) {

        if (!is_uploaded_file($file["tmp_name"]) || $file["error"] != 0) {
            return false;
        }
	
        if (!in_array(substr(strrchr($file["name"], "."), 1), explode("|", CMP_ARQ))) {
            return false;
        }

        $filename = date('dmY') . '_' . time() . $this->removeCaracteresEspeciais($file["name"]);
        $dir_upload = DIR_SITE . "../upload/{$tabela}/";

        if (!is_dir($dir_upload)) {
            mkdir($dir_upload);
        }

        if (!move_uploaded_file($file["tmp_name"], $dir_upload . $filename)) {
            return false;
        }

        $data = array();
        $data['arquivo'] = $filename;

        #$tamanho = ceil((filesize($dir_upload . $filename)) / 1024) . " KB";
        $tamanho = $this->formataBytes(filesize($dir_upload . $filename));
        $data['tamanho'] = $tamanho;

        return $data;
    }
    
    function formataBytes($size, $precision = 0) {
        $base = log($size) / log(1024);
        $suffixes = array(' B', ' KB', ' MB', ' GB', ' TB');

        return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
    }
    
    public function gerarHash($prefixo = ''){
        return strtoupper(md5($prefixo . uniqid(rand(), true)));
    }
    
}