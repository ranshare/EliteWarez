<?php

/**
 * A PHP class for database connection
 * @author Erick Bosco
 */
class DB {

    protected $con = null;
    private $host = null;
    private $dbname = null;
    private $user = null;
    private $pwd = null;
    private $charset  = null;
    protected $data = null;
    protected $where = '';

    /**
     * construct method
     * @param String $host - IP or domain of host MySQL Database
     * @param String $dbname - database name (schema)
     * @param String $username - username MySQL
     * @param String $password - password MySQL
     */
    function __construct($host = HOST_DB, $dbname = DBNAME_DB, $username = USER_DB, $password = PASS_DB, $charset = CHARSET_DB) {
        $this->host = $host;
        $this->dbname = $dbname;
        $this->user = $username;
        $this->pwd = $password;
        $this->charset = $charset;
        try {
            $this->con = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=$this->charset", $this->user, $this->pwd);
        } catch (PDOException $erro) {
            die('ERRO: ' . $erro->getMessage());
        }
    }

    /**
     * method to get MySQL Connection
     * @return PDO $con - return the connection in object(PDO)
     */
    public function getConnection() {
        try {
            if ($this->con == null) {
                $this->con = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=$this->charset", $this->user, $this->pwd);
            }
            return $this->con;
        } catch (PDOException $erro) {
            die('ERROR CONNECTION DB: ' . $erro->getMessage());
        }
    }

}
