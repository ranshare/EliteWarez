<?php
class Paginacao {
	/**
	 *
	 * @param type $totalRegistros
	 * @param type $limitePorPagina
	 * @param type $linkPaginacao
	 * @return type
	 */
	public static function montaPainelPaginacao($totalRegistros, $limitePorPagina, $linkPaginacao) {

		define("MAXPAGES",5,true);
		define("TOTALPAGES",ceil($totalRegistros/$limitePorPagina),true);
		define("HALFPAGES",ceil(MAXPAGES/2),true);

		$painel = $antes = $depois = "";
		$pagina = isset($_GET["pagina"]) ? $_GET["pagina"] : 1;

		$Functions = new Functions();

		//aqui monta a l�gica das paginas para tr�s e frente...
		if ($pagina > HALFPAGES ) {
			if (MAXPAGES > TOTALPAGES) {
				$firstVisible = 1;
				$lastVisible  = $pagina + HALFPAGES;
			} else {
				$firstVisible = $pagina - HALFPAGES;
				$lastVisible  = $pagina + HALFPAGES;
			}
		} else {
			$firstVisible = 1;
			$lastVisible  = MAXPAGES;
		}

		// RECUPERA OS PARAMETROS DA URL
		$param = explode(".php?", $_SERVER["REQUEST_URI"]);
		$param = isset($param[1]) ? $param[1] : "";

		//faz algo...
		$param = explode("&pagina=", $param);
		$param = isset($param[0]) ? $param[0] : "";

		//SE TOTAL DE PAGINAS MENOR QUE MAXPAGES, N�O EXIBE FRIST E LAST
		if (MAXPAGES < TOTALPAGES) {
			
			//echo TOTALPAGES." > ".MAXPAGES." AND  (".TOTALPAGES."-".HALFPAGES.") > $pagina" ;
			if (TOTALPAGES > MAXPAGES &&  (TOTALPAGES - HALFPAGES) > $pagina) {
				$depois = '<li class="next"><a href="'.$Functions->gerarLink($linkPaginacao."&pagina=".TOTALPAGES).'"> '.TOTALPAGES.'</a></li>';
			}
			
			//mostra a Pagina 1 caso a pagina seja maior que o m�ximo de pages.
			if ($pagina > HALFPAGES+1) {
				$antes = '<li class="prev"><a href="'.$Functions->gerarLink($linkPaginacao."&pagina=1").'>1 </a></li>';
			}
			
			if (MAXPAGES > (TOTALPAGES - $firstVisible)) {
				$firstVisible = $firstVisible - (MAXPAGES - (TOTALPAGES - $firstVisible));
			}
			
		}

		//verifica se a ultima p�gina j� chegou
		if ($lastVisible > TOTALPAGES) {
			$lastVisible = TOTALPAGES;
		}

		//gera o bot�o p�gina
		if ($pagina > 1) {
			$prev = $pagina - 1;
			$prev_link = '<li class="prev"><a href="'.$Functions->gerarLink($linkPaginacao."&pagina=".$prev).'">&lsaquo;</a></li>';
		} else {
			$prev_link = '<li class="ant">&lsaquo;</li>';
		}

		//gera o bot�o p�gina
		if (TOTALPAGES > $pagina) {
			$next = $pagina + 1;
			$next_link = '<li class="next"><a href="'.$Functions->gerarLink($linkPaginacao."&pagina=".$next).'">&rsaquo;</a></li>';
		} else {
			$next_link = '<li class="next">&rsaquo;</li>';
		}

		//gera os botoes numeros
		for ($x = $firstVisible; $x <= $lastVisible; $x++) {
			if ($x == $pagina) {
				$painel .= '<li class="selected"><a>'.$x.'</a></li>';
			} else {
				$painel .= '<li><a href="'.$Functions->gerarLink($linkPaginacao."&pagina=".$x).'">'.$x.'</a></li>';
			}
		}

		//retorna geral
		if ($totalRegistros > $limitePorPagina) {
			return utf8_encode('<ul class="paginacao">'." $prev_link $antes $painel $depois $next_link </ul><br />");
		} else { //ou nao retorna nada
			return null;
		}

	}

}
?>