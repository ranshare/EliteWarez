<?php

class QuestionarioMOD extends DB {

    public function validaChave($chave) {
        $stmt = $this->con->prepare('SELECT * FROM questionario_x_aluno WHERE hash = :pChave AND respondido is null');
        $stmt->bindValue(':pChave', $chave, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
    
    public function getQuestionario($idquestionario) {
        $join = ' INNER JOIN questionario_x_aluno qa ON qa.idquestionario = q.idquestionario ';
        $stmt = $this->con->prepare("SELECT * FROM questionario q $join WHERE q.idquestionario = :pId AND respondido is null");
        $stmt->bindValue(':pId', $idquestionario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
   
    public function getQuestoes($idquestionario) {
        $join = " INNER JOIN pergunta ON pergunta.idpergunta = questionario_x_pergunta.idpergunta ";
        $stmt = $this->con->prepare("SELECT * FROM questionario_x_pergunta $join WHERE idquestionario = :pId");
        $stmt->bindValue(':pId', $idquestionario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
    public function getAlternativas($idpergunta) {
        $stmt = $this->con->prepare('SELECT * FROM pergunta_alternativa WHERE idpergunta = :pId ORDER BY RAND()');
        $stmt->bindValue(':pId', $idpergunta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
    public function setResposta($idpergunta, $reposta, $idaluno){
        $stmt = $this->con->prepare('INSERT INTO resposta (idpergunta, idaluno, resposta) VALUES (:pIdPergunta, :pIdAluno, :pResposta)');
        $stmt->bindValue(':pIdPergunta', $idpergunta, PDO::PARAM_INT);
        $stmt->bindValue(':pIdAluno', $idaluno, PDO::PARAM_INT);
        $stmt->bindValue(':pResposta', $reposta, PDO::PARAM_STR);
        $stmt->execute();
        return $this->con->lastInsertId();
    }
    
    public function marcarComoRespondido($hash){
        $stmt = $this->con->prepare("UPDATE questionario_x_aluno SET respondido = :pData WHERE hash = :pHash");
        $stmt->execute(
            array (
                ':pHash' => $hash,
                ':pData' => date("Y-m-d H:i:s")            
            )
        );
        return $stmt->rowCount();
    }

}