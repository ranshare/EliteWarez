<?php

class Questionario {
    
    private $model = null;
    public $dados = null;

    public function __construct() {

        if (isset($_GET["acao"])) {

            $this->template = $_GET["acao"] . ".php";

            if (method_exists($this, $_GET["acao"])) {
                $this->$_GET["acao"]();
            }
        } else {
            header("Location: " . PAGINA_NAO_ENCONTRADA);
        }
        
    }
    
    public function questionario(){
        
        $this->model = new QuestionarioMOD();

        if (isset($_GET['chave'])){
            if (is_object($chave = $this->model->validaChave($_GET['chave']))){
                $_SESSION['ALUNO']['ID'] = $chave->idaluno;
                $this->dados['questionario'] = $this->model->getQuestionario($chave->idquestionario);
                $this->dados['questoes'] = $this->model->getQuestoes($chave->idquestionario);
            }
        }
        
        if (!$this->dados['questionario']){
            header("Location: " . Functions::getInstance()->gerarLink("questionario/index.php?acao=erro"));
            exit;
        }
    }
    
    public function responder(){
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $this->model = new QuestionarioMOD();
            
            $respondeuPeloMenosUma = false;
            foreach ($_POST as $pergunta => $resposta){
                $temp = explode("-", $pergunta);
                if (is_numeric(end($temp))){
                    $idpergunta = (int)end($temp);
                    
                    if (is_array($resposta)){
                        $resposta = implode("; ", $resposta);
                    }
                    
                    if ($this->model->setResposta($idpergunta, $resposta, $_SESSION['ALUNO']['ID'])){
                        $respondeuPeloMenosUma = true;
                    }
                }
            }
            
            if ($respondeuPeloMenosUma){
                $this->model->marcarComoRespondido($_POST['hash']);
                header("Location: " . Functions::getInstance()->gerarLink("questionario/index.php?acao=mensagem&msg=ok"));
            } else {
                header("Location: " . Functions::getInstance()->gerarLink("questionario/index.php?acao=mensagem&msg=erroGravarRespostas"));
            }
            
            exit;
        }

    }
    
    public function getAlternativas($idpergunta){
        $this->model = new QuestionarioMOD();
        return $this->model->getAlternativas($idpergunta);
    }

}