<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <?php
        $JS_SITE = array('confirmarFecharJanela.js', 'validarRespostas.js');
        $CSS_SITE = array();
        include DIR_SITE . "includes/head.php";
        ?>
    </head>
    <body onbeforeunload="confClose(event);">
        <?php include DIR_SITE . 'includes/topo.php' ?>
        <div class="container">

            <div class="page-header">
                <h1><?php echo $controller->dados['questionario']->titulo; ?> <small><?php echo $controller->dados['questionario']->subtitulo; ?></small></h1>
            </div>
            
            <div>
                <div class="alert alert-warning alert-dismissible" role="alert">
                    <?php echo $controller->dados['questionario']->avisos; ?>
                </div>
            </div>

            <form method="post" action="<?php echo $Functions->gerarLink("questionario/index.php?acao=responder") ?>" onsubmit="return validarRespostas();">
                <input type="hidden" name="hash" value="<?php echo @$_GET['chave'];  ?>" />
                <input type="hidden" id="envio" value="false" />
                <div class="container">
                    <div class="panel-group" id="accordion">
                        <div class="faqHeader">Questões</div>
                        <?php
                        if (is_array($controller->dados['questoes'])):
                            foreach ($controller->dados['questoes'] as $questao):
                            ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#questao-<?php echo $questao->idpergunta; ?>">
                                                <?php echo $questao->descricao; ?>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="questao-<?php echo $questao->idpergunta; ?>" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                            <?php
                                            if ($questao->idpergunta_tipo == 1):
                                            ?>
                                                <textarea name="resposta-<?php echo $questao->idpergunta; ?>" class="form-control" placeholder="resposta"></textarea>
                                            <?php
                                            else :
                                                $nomeCampo = "resposta-$questao->idpergunta";
                                                if ($questao->idpergunta_tipo == 3):
                                                    $tipo = 'checkbox';
                                                    $nomeCampo .= "[]";
                                                else :
                                                    $tipo = 'radio';
                                                endif; 

                                                $alternativas = $controller->getAlternativas($questao->idpergunta);
                                                if (is_array($alternativas)):
                                                    foreach ($alternativas as $alternativa):
                                                    ?>
                                                    <input type="<?php echo $tipo; ?>" name="<?php echo $nomeCampo; ?>" value="<?php echo $alternativa->descricao; ?>" id="cmp-<?php echo $alternativa->idpergunta_alternativa; ?>" />
                                                    <label for="cmp-<?php echo $alternativa->idpergunta_alternativa; ?>"><?php echo $alternativa->descricao; ?></label>
                                                    <br />
                                                    <?php
                                                    endforeach;
                                                endif;
                                                ?>
                                            <?php
                                            endif;
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            endforeach;
                        endif;
                        ?>
                    </div>
                    <button class="button">Responder</button>
                </div>
            </form>
        </div>
        <?php include DIR_SITE . 'includes/rodape.php'; ?>
    </body>
</html>