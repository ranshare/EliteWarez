<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <?php
        $JS_SITE = array();
        $CSS_SITE = array();
        include DIR_SITE . "includes/head.php";
        ?>
    </head>
    <body>
        <?php include DIR_SITE . 'includes/topo.php' ?>
        <div class="container">

            <div class="page-header">
                <h1>Questionários <small>Envie suas respostas de forma rápida e precisa</small></h1>
            </div>

            <!-- Bootstrap FAQ - START -->
            <div class="container">
                <br />
                <br />
                <br />
                <?php
                $classe = 'success';
                $mensagem = 'Respostas enviadas com <strong>sucesso</strong>!';
                if (isset($_GET['msg'])){
                    if ($_GET['msg'] == 'erroGravarRespostas'){
                        $classe = 'danger';
                        $mensagem = 'Erro ao gravar respostas! Por favor, tente novamente mais tarde.';
                    }
                }
                ?>
                <div class="alert alert-<?php echo $classe; ?> alert-dismissible" role="alert">
                    <?php echo $mensagem; ?>
                </div>

                <br />
            </div>
        </div>
        <?php include DIR_SITE . 'includes/rodape.php'; ?>
    </body>
</html>