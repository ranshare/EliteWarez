<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <?php
        $JS_SITE = array();
        $CSS_SITE = array();
        include DIR_SITE . "includes/head.php";
        ?>
    </head>
    <body>
        <?php include DIR_SITE . 'includes/topo.php' ?>
        <div class="container">

            <div class="page-header">
                <h1>Bootstrap FAQ <small>Bootsrap Frequently Asked Questions</small></h1>
            </div>

            <!-- Bootstrap FAQ - START -->
            <div class="container">
                <br />
                <br />
                <br />

                <div class="alert alert-warning alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    Chave <strong>Inválida</strong>. 
                </div>

                <br />
            </div>
        </div>
        <?php include DIR_SITE . 'includes/rodape.php'; ?>
    </body>
</html>