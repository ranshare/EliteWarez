function confClose(e) {
    e.returnValue = "Deseja realmente sair? Todas as respostas serão descartadas!";
}