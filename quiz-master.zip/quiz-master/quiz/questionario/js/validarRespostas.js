function validarRespostas() {

    var ok = true;

    if ($("input[type='radio']").size() > 0) {
        if ($("input[type='radio']:checked").size() > 0) {
            $("input[type='radio']:checked").each(function () {
                if (this.value == '') {
                    this.focus();
                    ok = false;
                    return false;
                }
            });
        } else {
            ok = false;
            return false;
        }
    }

    if ($("input[type='checkbox']").size() > 0) {
        if ($("input[type='checkbox']:checked").size() > 0) {
            $("input[type='checkbox']:checked").each(function () {
                if (this.value == '') {
                    this.focus();
                    ok = false;
                    return false;
                }
            });
        } else {
            ok = false;
            return false;
        }
    }

    $("textarea").each(function () {
        if (this.value == '') {
            this.focus();
            ok = false;
            return false;
        }
    });

    document.body.onbeforeunload = 'confClose(event,1);'
    return ok;
}