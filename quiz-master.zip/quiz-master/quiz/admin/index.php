<?php

require '../global.php';

$controller = new Admin();

if ($controller) {
    if (file_exists("view/" . $controller->template)) {
        include_once "view/" . $controller->template;
        exit;
    }
}
header("Location: " . URL_SITE);
exit;