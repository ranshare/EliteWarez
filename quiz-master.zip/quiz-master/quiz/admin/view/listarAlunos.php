<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <?php
        $JS_SITE = array('enviarQuestionario.js');
        $CSS_SITE = array();
        include DIR_SITE . "includes/head.php";
        ?>
        <meta http-equiv="refresh" content="10" />
    </head>
    <body>
        <?php include DIR_SITE . 'includes/topo.php' ?>
        <div class="container">

            <div class="page-header">
                <h1>Alunos <small>Listagem dos alunos</small></h1>
            </div>

            <div class="col-lg-12">
                <form>
                    <input type="hidden" name="acao" value="listarAlunos" />
                    <select id="questionarios" name="questionario" onchange="form.submit()">
                        <option value="">Questionários...</option>
                        <?php
                        if (is_array($controller->dados['questionarios'])):
                            foreach ($controller->dados['questionarios'] as $questionario):
                            ?>
                                <option value="<?php echo $questionario->idquestionario; ?>" <?php echo $questionario->idquestionario == @$_GET['questionario'] ? ' selected' : ''; ?>>
                                    <?php echo $questionario->titulo; ?>
                                </option>
                            <?php
                            endforeach;
                        endif;
                        ?>
                    </select>
                </form>
                <a class="btn-xs" href="javascript:enviarQuestionarioTodos();">Enviar para todos da lista</a>
            </div>
            
            <div class="col-lg-12" id="listaAlunos">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th class="text-center">Status</th>
                            <th>Chave</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (is_array($controller->dados['alunos'])):
                            foreach ($controller->dados['alunos'] as $aluno):
                                ?>
                                <tr>
                                    <td><?php echo $aluno->nome; ?></td>
                                    <td><?php echo $aluno->email; ?></td>
                                    <td class="text-center">
                                        <?php
                                        $ultimoQuestionario = $controller->getUltimoQuestionarioAluno($aluno->idaluno, @$_GET['questionario']);
                                        if (is_object($ultimoQuestionario)):
                                        ?>
                                            <span class="glyphicon glyphicon-remove" title="Não Respondido"></span>
                                        <?php
                                        else:
                                        ?>
                                            <span class="glyphicon glyphicon-ok" title="Respondido"></span>
                                        <?php
                                        endif;
                                        ?>                                        
                                    </td>
                                    <td>
                                        <?php
                                        /*
                                        <a href="javascript:enviarQuestionario('<?php echo $aluno->idaluno; ?>');" class="glyphicon glyphicon-share-alt" title="Enviar Questionário"></a>
                                        */
                                        if (is_object($ultimoQuestionario)):
                                            echo $ultimoQuestionario->hash;
                                        endif;
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            endforeach;
                        endif;
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php include DIR_SITE . 'includes/rodape.php'; ?>
    </body>
</html>