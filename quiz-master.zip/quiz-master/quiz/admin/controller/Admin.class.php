<?php

class Admin {
    
    private $model = null;
    public $dados = null;

    public function __construct() {

        if (isset($_GET["acao"])) {

            $this->template = $_GET["acao"] . ".php";

            if (method_exists($this, $_GET["acao"])) {
                $this->$_GET["acao"]();
            }
        } else {
            header("Location: " . PAGINA_NAO_ENCONTRADA);
        }
        
    }
    
    public function listarAlunos(){
        $this->model = new AdminMOD();
        $this->dados['alunos'] = $this->model->getAlunos();
        $this->dados['questionarios'] = $this->model->getQuestionarios();
    }
    
    public function getUltimoQuestionarioAluno($idaluno, $idquestionario){
        $MOD = new AdminMOD();
        return $MOD->getUltimoQuestionarioAluno($idaluno, $idquestionario);
    }
    
    public function enviarQuestionario(){
        $this->model = new AdminMOD();
        $temp = $this->model->enviarLinkQuestionario(1);
        #var_dump($temp);
        die;
    }
    
//    public function gerarHashAlunos(){
//        $this->model = new AdminMOD();
//        $alunos = $this->model->getAlunos();
//        foreach ($alunos as $aluno){
//            $prefixo = $aluno->idaluno . "1";
//            echo "UPDATE questionario_x_aluno SET hash = '";
//            echo $this->model->gerarHash($prefixo);
//            echo "' WHERE idaluno = $aluno->idaluno AND idquestionario = 1;";
//            echo "<br>";
//        }
//        die;
//    }

}