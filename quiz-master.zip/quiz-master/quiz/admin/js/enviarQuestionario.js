function enviarQuestionario(idaluno){
    alert('ok'+idaluno);
}

function enviarQuestionarioTodos(){
    var idquestionario = $("#questionarios").val();
    alert('ok' + idquestionario);
}