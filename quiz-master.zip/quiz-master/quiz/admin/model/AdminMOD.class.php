<?php

class AdminMOD extends DB {

    public function getAlunos(){
        $stmt = $this->con->prepare('SELECT * FROM aluno');
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
    public function getQuestionarios(){
        $stmt = $this->con->prepare('SELECT * FROM questionario');
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
    public function getUltimoQuestionarioAluno($idaluno, $idquestionario){
        $stmt = $this->con->prepare('SELECT * FROM questionario_x_aluno WHERE idquestionario = :pIdQuestionario AND idaluno = :pIdAluno ORDER BY idquestionario_x_aluno DESC');
        $stmt->bindValue(':pIdQuestionario', $idquestionario, PDO::PARAM_INT);
        $stmt->bindValue(':pIdAluno', $idaluno, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
    
}