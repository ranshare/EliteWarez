<?php

include_once "../global.php";

header("Content-type: text/javascript");

$script = "";

/* ARQUIVOS JS PADRAO */
$script .= file_get_contents("jquery.js");
$script .= file_get_contents("validate.js");
$script .= file_get_contents("bootstrap.js");

/* FAZ A INCLUSAO ARQUIVOS DE JS ESPECIFICADOS */
if (isset($_GET["files"]) && !empty($_GET["files"])) {
    $array_js = explode(",", $_GET["files"]);

    if (is_array($array_js)) {
        foreach ($array_js as $js) {
            if (file_exists($js)) {
                $script .= file_get_contents($js);
            } else {
                $js_mod = $Functions->getArquivoModulo($js, "js");
                if (file_exists($js_mod)) {
                    $script .= file_get_contents($js_mod);
                }
            }
        }
    }
}

if (COMPRIMIR_JS) {
    $packer = new JavaScriptPacker($script, "Normal", true, false);
    $packed = $packer->pack();

    echo $packed;
} else {
    echo $script;
}
?>