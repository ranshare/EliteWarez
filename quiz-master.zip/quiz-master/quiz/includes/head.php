<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Questionários</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language" content="pt" />
<meta name="rating" content="General" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<meta name="author" content="Erick Bosco" />
<meta name="language" content="pt-br" />
<meta name="title" content="Questionários" />
<link rel="shortcut icon" href="<?=URL_SITE ?>img/db_icone.ico" type="image/x-icon" />
<script type="text/javascript" src="<?=URL_SITE ?>js/scripts.php?files=<?=Functions::getIn($JS_SITE); ?>"></script>
<link rel="stylesheet" href="<?=URL_SITE ?>css/estilos.php?files=<?=Functions::getIn($CSS_SITE); ?>" type="text/css" media="screen" />